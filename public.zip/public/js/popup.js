/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 4);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */,
/* 1 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony default export */ __webpack_exports__["a"] = (function (page) {
  (function (i, s, o, g, r, a, m) {
    i.GoogleAnalyticsObject = r;
    i[r] = i[r] || function () {
      (i[r].q = i[r].q || []).push(arguments);
    }, i[r].l = 1 * new Date();
    a = s.createElement(o), m = s.getElementsByTagName(o)[0];
    a.async = 1;
    a.src = g;
    m.parentNode.insertBefore(a, m);
  })(window, document, 'script', 'https://www.google-analytics.com/analytics.js', 'ga');

  ga('create', 'UA-162836929-1', 'auto');
  ga('require', 'displayfeatures'); // Modifications:

  ga('set', 'checkProtocolTask', null); // Disables file protocol checking.

  ga('send', 'pageview', page); // Set page, avoiding rejection due to chrome-extension protocol
});

/***/ }),
/* 2 */,
/* 3 */,
/* 4 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXTERNAL MODULE: ./src/analytics.js
var analytics = __webpack_require__(1);

// CONCATENATED MODULE: ./src/utils/htmlToElement/htmlToElement.js
/* harmony default export */ var htmlToElement = (function (html) {
  var template = document.createElement('template');
  html = html.trim(); // Never return a text node of whitespace as the result

  template.innerHTML = html;
  return template.content.firstChild;
});
// CONCATENATED MODULE: ./src/utils/htmlToElement/index.js

// CONCATENATED MODULE: ./node_modules/nanoid/index.browser.js
// This file replaces `index.js` in bundlers like webpack or Rollup,
// according to `browser` config in `package.json`.

if (false) {}

// This alphabet uses `A-Za-z0-9_-` symbols. The genetic algorithm helped
// optimize the gzip compression for this alphabet.
let urlAlphabet =
  'ModuleSymbhasOwnPr-0123456789ABCDEFGHNRVfgctiUvz_KqYTJkLxpZXIjQW'

let random = bytes => crypto.getRandomValues(new Uint8Array(bytes))

let customRandom = (alphabet, size, getRandom) => {
  // First, a bitmask is necessary to generate the ID. The bitmask makes bytes
  // values closer to the alphabet size. The bitmask calculates the closest
  // `2^31 - 1` number, which exceeds the alphabet size.
  // For example, the bitmask for the alphabet size 30 is 31 (00011111).
  // `Math.clz32` is not used, because it is not available in browsers.
  let mask = (2 << Math.log(alphabet.length - 1) / Math.LN2) - 1
  // Though, the bitmask solution is not perfect since the bytes exceeding
  // the alphabet size are refused. Therefore, to reliably generate the ID,
  // the random bytes redundancy has to be satisfied.

  // Note: every hardware random generator call is performance expensive,
  // because the system call for entropy collection takes a lot of time.
  // So, to avoid additional system calls, extra bytes are requested in advance.

  // Next, a step determines how many random bytes to generate.
  // The number of random bytes gets decided upon the ID size, mask,
  // alphabet size, and magic number 1.6 (using 1.6 peaks at performance
  // according to benchmarks).

  // `-~f => Math.ceil(f)` if f is a float
  // `-~i => i + 1` if i is an integer
  let step = -~(1.6 * mask * size / alphabet.length)

  return () => {
    let id = ''
    while (true) {
      let bytes = getRandom(step)
      // A compact alternative for `for (var i = 0; i < step; i++)`.
      let j = step
      while (j--) {
        // Adding `|| ''` refuses a random byte that exceeds the alphabet size.
        id += alphabet[bytes[j] & mask] || ''
        // `id.length + 1 === size` is a more compact option.
        if (id.length === +size) return id
      }
    }
  }
}

let customAlphabet = (alphabet, size) => customRandom(alphabet, size, random)

let nanoid = (size = 21) => {
  let id = ''
  let bytes = crypto.getRandomValues(new Uint8Array(size))

  // A compact alternative for `for (var i = 0; i < step; i++)`.
  while (size--) {
    // It is incorrect to use bytes exceeding the alphabet size.
    // The following mask reduces the random byte in the 0-255 value
    // range to the 0-63 value range. Therefore, adding hacks, such
    // as empty string fallback or magic numbers, is unneccessary because
    // the bitmask trims bytes down to the alphabet size.
    let byte = bytes[size] & 63
    if (byte < 36) {
      // `0-9a-z`
      id += byte.toString(36)
    } else if (byte < 62) {
      // `A-Z`
      id += (byte - 26).toString(36).toUpperCase()
    } else if (byte < 63) {
      id += '_'
    } else {
      id += '-'
    }
  }
  return id
}



// CONCATENATED MODULE: ./src/components/toggle-switch/toggle-switch.js
function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }




var toggle_switch_ToggleSwitch = /*#__PURE__*/function () {
  function ToggleSwitch(_ref) {
    var onClick = _ref.onClick,
        _ref$isChecked = _ref.isChecked,
        isChecked = _ref$isChecked === void 0 ? false : _ref$isChecked;

    _classCallCheck(this, ToggleSwitch);

    this.id = nanoid();
    this.onClick = onClick;
    this.isChecked = isChecked;
    this.element = null;
  }

  _createClass(ToggleSwitch, [{
    key: "handleClick",
    value: function handleClick(e) {
      this.isChecked = e.target.checked;
      this.onClick(this.isChecked);
    }
  }, {
    key: "render",
    value: function render() {
      if (!this.element) {
        this.element = htmlToElement("\n            <div class=\"toggle-switch\">\n                <input id=\"".concat(this.id, "\" type=\"checkbox\" class=\"toggle-switch__input\" />\n                <label for=\"").concat(this.id, "\"  class=\"toggle-switch__label\">\n                    <span class=\"toggle-switch__label--off\">OFF</span>\n                    <span class=\"toggle-switch__label--on\">ON</span>\n                  \n                </label>\n            </div>\n        "));
        var input = this.element.querySelector("input");
        input.checked = this.isChecked;
        input.addEventListener('click', this.handleClick.bind(this));
      }

      return this.element;
    }
  }]);

  return ToggleSwitch;
}();


// CONCATENATED MODULE: ./src/components/toggle-switch/index.js

// CONCATENATED MODULE: ./src/popup/popup.js


document.addEventListener("DOMContentLoaded", function () {
  Object(analytics["a" /* default */])("/page");
  getMIUEnableValue().then(function (isMIUEnabled) {
    var disableSwitch = new toggle_switch_ToggleSwitch({
      onClick: function onClick(value) {
        return setAndSendMIUEnableValue(value);
      },
      isChecked: isMIUEnabled
    });
    document.querySelector(".popup__items").appendChild(disableSwitch.render());
  });
  document.getElementById('addToDanger').addEventListener('click', addActiveUrlToDanger);
  document.getElementById('goToOptions').addEventListener('click', goToOptions);
});

function goToOptions() {
  chrome.tabs.create({
    url: 'options.html'
  });
}

function addActiveUrlToDanger(e) {
  chrome.storage.sync.get(['dangerList'], function (result) {
    var dangerList = [];

    if (result.dangerList) {
      dangerList = result.dangerList;
    }

    chrome.tabs.query({
      active: true,
      currentWindow: true
    }, function (tabs) {
      var alreadyExits = dangerList.some(function (url) {
        return tabs[0].url == url;
      });

      if (!alreadyExits) {
        dangerList.push(tabs[0].url);
        chrome.storage.sync.set({
          dangerList: dangerList
        }, function () {
          chrome.tabs.update(tabs[0].id, {
            url: tabs[0].url
          });
        });
      }
    });
  });
}

function getMIUEnableValue() {
  return new Promise(function (resolve, reject) {
    chrome.storage.sync.get(['isMIUEnabled'], function (result, error) {
      if (error) {
        reject(error);
      } else {
        resolve(result.isMIUEnabled);
      }
    });
  });
}

function setAndSendMIUEnableValue(value) {
  chrome.storage.sync.set({
    isMIUEnabled: value
  }, function () {});
}

/***/ })
/******/ ]);